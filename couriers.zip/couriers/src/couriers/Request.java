package couriers;

public class Request {
	private int id;  
	private String name,email,destination,aprox,address,mobile;  
	public int getId() {  
	    return id;  
	}  
	public void setId(int id) {  
	    this.id = id;  
	}  
	public String getName() {  
	    return name;  
	}  
	public void setName(String name) {  
	    this.name = name;  
	}  
	
	
	public String getEmail() {  
	    return email;  
	}  
	public void setEmail(String email) {  
	    this.email = email;  
	}  
	
	public String getDestination() {  
	    return destination;  
	}
	public void setDestination(String destination) {  
	    this.destination = destination;  
	} 
	
	public String getAprox() {  
	    return aprox;  
	}
	public void setAprox(String aprox) {  
	    this.aprox = aprox;  
	} 
	public String getAddress() {  
	    return address;  
	}
	public void setAddress(String address) {  
	    this.address = address;  
	} 
	
	public String getMobile() {  
	    return address;  
	}
	public void setMobile(String mobile) {  
	    this.mobile = mobile;  
	} 
	
	
}
