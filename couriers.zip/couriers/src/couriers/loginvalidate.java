package couriers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/loginvalidate") 
public class loginvalidate extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	java.sql.Connection con=null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("psw");
		
		try{
			  
			  con = DatabaseConnection.intializeDatabase(); 
			 java.sql.PreparedStatement st=con.prepareStatement("select username, psw from courier where username=? and psw=?");
			 
			
			 st.setString(1, request.getParameter("username"));
			 st.setString(2, request.getParameter("psw"));
            java.sql.ResultSet rs=st.executeQuery();
            while(rs.next()){
            	response.sendRedirect("navbar.html");
            	return ;
            	
            }
			response.sendRedirect("Error.html"); 
			return;
			
			 
		  } catch(Exception e)
		{
		e.printStackTrace();
		System.out.println("Exception is coming here.!!");
			  
		}
 
	
	}
}

