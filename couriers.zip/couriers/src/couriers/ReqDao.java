package couriers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ReqDao {
	public static int save(Deliver e){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into request(name,email,destination,aprox,address,mobile) values (?,?,?,?,?,?)");  
            ps.setString(1,e.getName());  
          
            ps.setString(2,e.getEmail());  
           
            ps.setString(3,e.getDestination());
            ps.setString(4,e.getAprox());
           
            ps.setString(5,e.getAddress());
            ps.setString(6,e.getMobile());
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int update(Deliver e){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement(  
                         "update request set name=?,email=?,destination=?,aprox=?,address=?,mobile=? where id=?");  
            ps.setString(1,e.getName());  
          
            ps.setString(2,e.getEmail());  
          
            ps.setString(3,e.getDestination());  
            ps.setString(4,e.getAprox()); 
            ps.setString(5,e.getAddress()); 
            ps.setString(6,e.getMobile()); 
            ps.setInt(7,e.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("delete from request where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Request getEmployeeById(int id){  
        Deliver e=new Deliver();  
          
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("select * from request where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
             
                e.setEmail(rs.getString(3));  
               
                e.setDestination(rs.getString(4));  
                e.setAprox(rs.getString(5));  
                e.setAddress(rs.getString(6));  
                e.setMobile(rs.getString(7));  
                
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return e;  
    }  
    public static List<Deliver> getAllEmployees(){  
        List<Deliver> list=new ArrayList<Deliver>();  
          
        try{  
            Connection con=DatabaseConnection.intializeDatabase();  
            PreparedStatement ps=con.prepareStatement("select * from request");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Request e=new Request();  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
             
                e.setEmail(rs.getString(3));  
               
                e.setDestination(rs.getString(4));  
                e.setAprox(rs.getString(5));  
                e.setAddress(rs.getString(6));  
                e.setMobile(rs.getString(7));  
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}



